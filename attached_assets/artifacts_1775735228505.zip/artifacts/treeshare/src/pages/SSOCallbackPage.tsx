import { AuthenticateWithRedirectCallback } from "@clerk/react";

export default function SSOCallbackPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-3">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        <p className="text-sm text-muted-foreground">Completamento accesso...</p>
      </div>
      <AuthenticateWithRedirectCallback />
    </div>
  );
}
