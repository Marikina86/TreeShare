import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";

export const problemReportsTable = pgTable("problem_reports", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  username: text("username"),
  category: text("category").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("new"),
  adminNote: text("admin_note"),
  adminReply: text("admin_reply"),
  repliedAt: timestamp("replied_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type ProblemReport = typeof problemReportsTable.$inferSelect;
