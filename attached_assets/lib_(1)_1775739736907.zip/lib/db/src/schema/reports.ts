import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";

export const reportsTable = pgTable("reports", {
  id: serial("id").primaryKey(),
  reporterUserId: text("reporter_user_id").notNull(),
  reportedUserId: text("reported_user_id").notNull(),
  reportedUsername: text("reported_username"),
  treeId: integer("tree_id"),
  eventId: integer("event_id"),
  eventTitle: text("event_title"),
  reason: text("reason").notNull(),
  notes: text("notes"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Report = typeof reportsTable.$inferSelect;
