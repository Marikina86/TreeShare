import { pgTable, serial, integer, text, timestamp, boolean } from "drizzle-orm/pg-core";
import { treesTable } from "./trees";

export const weeklyWinnersTable = pgTable("weekly_winners", {
  id: serial("id").primaryKey(),
  treeId: integer("tree_id").notNull().references(() => treesTable.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull(),
  province: text("province").notNull(),
  weekStart: timestamp("week_start").notNull(),
  sunCount: integer("sun_count").notNull(),
  notified: boolean("notified").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type WeeklyWinner = typeof weeklyWinnersTable.$inferSelect;
