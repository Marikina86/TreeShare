import {
  pgTable,
  text,
  serial,
  integer,
  timestamp,
  doublePrecision,
  boolean,
  unique,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const treesTable = pgTable("trees", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  photoUrl: text("photo_url").notNull(),
  photoThumbnailUrl: text("photo_thumbnail_url"),
  plantName: text("plant_name"),
  caption: text("caption"),
  species: text("species"),
  plantedAt: timestamp("planted_at"),
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
  locationName: text("location_name"),
  country: text("country"),
  mapsUrl: text("maps_url"),
  province: text("province"),
  verificationBypassed: boolean("verification_bypassed").notNull().default(false),
  photoStatus: text("photo_status").notNull().default("approved"),
  sunCount: integer("sun_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const treeUpdatesTable = pgTable("tree_updates", {
  id: serial("id").primaryKey(),
  treeId: integer("tree_id").notNull().references(() => treesTable.id, { onDelete: "cascade" }),
  photoUrl: text("photo_url").notNull(),
  note: text("note"),
  photoStatus: text("photo_status").notNull().default("approved"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const treeSunsTable = pgTable("tree_suns", {
  id: serial("id").primaryKey(),
  treeId: integer("tree_id").notNull().references(() => treesTable.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  unique("tree_suns_user_tree_unique").on(table.treeId, table.userId),
]);

export const insertTreeSchema = createInsertSchema(treesTable).omit({
  id: true,
  createdAt: true,
});

export const insertTreeUpdateSchema = createInsertSchema(treeUpdatesTable).omit({
  id: true,
  createdAt: true,
});

export type InsertTree = z.infer<typeof insertTreeSchema>;
export type Tree = typeof treesTable.$inferSelect;
export type InsertTreeUpdate = z.infer<typeof insertTreeUpdateSchema>;
export type TreeUpdate = typeof treeUpdatesTable.$inferSelect;
