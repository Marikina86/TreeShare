import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export function validatePartitaIVA(piva: string): boolean {
  const clean = piva.replace(/\s/g, "");
  if (!/^\d{11}$/.test(clean)) return false;
  let sum = 0;
  for (let i = 0; i < 10; i++) {
    const d = parseInt(clean[i]!, 10);
    if (i % 2 === 0) {
      sum += d;
    } else {
      const doubled = d * 2;
      sum += doubled > 9 ? doubled - 9 : doubled;
    }
  }
  const check = (10 - (sum % 10)) % 10;
  return check === parseInt(clean[10]!, 10);
}

export function validateCodiceFiscaleEnte(cf: string): boolean {
  const clean = cf.replace(/\s/g, "").toUpperCase();
  if (/^\d{11}$/.test(clean)) return validatePartitaIVA(clean);
  if (/^[A-Z0-9]{16}$/.test(clean)) return true;
  return false;
}

export const organizationsTable = pgTable("organizations", {
  id: serial("id").primaryKey(),

  ragioneSociale: text("ragione_sociale").notNull(),
  partitaIva: text("partita_iva").notNull(),
  codiceFiscale: text("codice_fiscale").notNull(),
  codiceUnivoco: text("codice_univoco").notNull(),
  formaGiuridica: text("forma_giuridica").notNull(),
  numeroRegistroImprese: text("numero_registro_imprese"),

  indirizzoVia: text("indirizzo_via").notNull(),
  indirizzoCitta: text("indirizzo_citta").notNull(),
  indirizzoCap: text("indirizzo_cap").notNull(),
  indirizzoStato: text("indirizzo_stato").notNull(),

  emailUfficiale: text("email_ufficiale").notNull().unique(),
  telefono: text("telefono").notNull(),
  referenteNome: text("referente_nome").notNull(),
  referenteCognome: text("referente_cognome").notNull(),

  username: text("username").notNull().unique(),
  hashedPassword: text("hashed_password").notNull(),
  ruoloUtente: text("ruolo_utente").notNull(),
  numeroLicenze: integer("numero_licenze").notNull().default(1),

  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const registerEnteSchema = z.object({
  ragioneSociale: z.string().min(2, "Ragione sociale obbligatoria").max(200),

  partitaIva: z
    .string()
    .min(11, "La Partita IVA deve essere di 11 cifre")
    .max(11, "La Partita IVA deve essere di 11 cifre")
    .regex(/^\d{11}$/, "La Partita IVA deve contenere solo 11 cifre")
    .refine((v) => validatePartitaIVA(v), "Partita IVA non valida (checksum errato)"),

  codiceFiscale: z
    .string()
    .min(11, "Codice fiscale obbligatorio")
    .max(16, "Codice fiscale non valido")
    .refine((v) => validateCodiceFiscaleEnte(v), "Codice fiscale non valido"),

  codiceUnivoco: z
    .string()
    .min(6, "Il Codice Univoco SDI deve avere 6 o 7 caratteri")
    .max(7, "Il Codice Univoco SDI deve avere 6 o 7 caratteri")
    .regex(/^[A-Z0-9]{6,7}$/i, "Codice Univoco SDI non valido (6-7 caratteri alfanumerici)"),

  formaGiuridica: z.enum([
    "srl",
    "spa",
    "sas",
    "snc",
    "ditta_individuale",
    "associazione",
    "fondazione",
    "cooperativa",
    "ente_pubblico",
    "altro",
  ]),
  numeroRegistroImprese: z.string().max(50).optional(),

  indirizzoVia: z.string().min(3, "Indirizzo obbligatorio").max(200),
  indirizzoCitta: z.string().min(2, "Città obbligatoria").max(100),
  indirizzoCap: z.string().min(4, "CAP obbligatorio").max(10),
  indirizzoStato: z.string().min(2, "Stato obbligatorio").max(100),

  emailUfficiale: z.email("Email non valida"),
  telefono: z.string().min(6, "Telefono obbligatorio").max(20),
  referenteNome: z.string().min(2, "Nome referente obbligatorio").max(100),
  referenteCognome: z.string().min(2, "Cognome referente obbligatorio").max(100),

  username: z
    .string()
    .min(3, "Username minimo 3 caratteri")
    .max(50)
    .regex(/^[a-zA-Z0-9_]+$/, "Solo lettere, numeri e underscore"),
  password: z.string().min(8, "Password minimo 8 caratteri").max(100),
  ruoloUtente: z.enum(["admin", "manager", "referente", "operatore"]),
  numeroLicenze: z.number().int().min(1, "Minimo 1 licenza").max(10000),
});

export type RegisterEnteInput = z.infer<typeof registerEnteSchema>;
export type Organization = typeof organizationsTable.$inferSelect;
