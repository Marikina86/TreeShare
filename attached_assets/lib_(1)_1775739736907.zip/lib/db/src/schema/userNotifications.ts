import { pgTable, text, serial, timestamp, boolean, integer } from "drizzle-orm/pg-core";

export const userNotificationsTable = pgTable("user_notifications", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull().default("system"), // "admin_reply" | "system"
  relatedId: integer("related_id"),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type UserNotification = typeof userNotificationsTable.$inferSelect;
