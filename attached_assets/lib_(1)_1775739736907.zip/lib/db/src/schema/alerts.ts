import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";

export const alertsTable = pgTable("alerts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  priority: text("priority").notNull().default("normal"), // low | normal | high | critical
  createdBy: text("created_by").notNull(), // clerk user ID dell'admin
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type Alert = typeof alertsTable.$inferSelect;
